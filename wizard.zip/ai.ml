type t = { player : Player.t }

let pick_best_card = failwith "unimplemented"

# ocaml-Wizard
![](https://i.ebayimg.com/images/g/UmQAAOSwge9gU7Ju/s-l225.jpg) <br>
(img source) https://www.ebay.com/p/84459156
## 3110 Final Project
We have created the card game called Wizard, which can be seen here: https://en.wikipedia.org/wiki/Wizard_(card_game).

## Installation
No additional dependencies are required. <br>
To play the game run, <br>
```` make clean ```` <br> 
```` make play````
## How to Play
To play first enter in a valid deck, in this case a great deck to use is ````main_deck.json````. <br>
Next select the number of players, it expects you to give it a ````int````.<br>
Next each player will make a bet this expects an ````int````. <br>
Next each player will select a card, use the commands ````prev````, ````next```` to move the selected card. 
Once a card is selected type ````select```` to equipt the card.

## Contributors
pcm82 <br> ml2359 <br> hes227


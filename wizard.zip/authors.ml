let hours_worked = 43
